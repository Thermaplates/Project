# First setup
- cd && rm -rf x
- curl https://raw.githubusercontent.com/FLeafs/x/main/setup.sh -o setup.sh
- chmod +x ./setup.sh
- ./setup.sh

# Run
- cd && cd x && node index.js

# Tutorial
- Website : http://127.0.0.1:8080/
- Video : https://youtu.be/7YGstIc-UZw
